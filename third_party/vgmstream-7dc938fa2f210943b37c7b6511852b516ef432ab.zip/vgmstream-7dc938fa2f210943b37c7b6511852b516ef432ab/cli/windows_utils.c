#if defined(VGM_STDIO_UNICODE) && defined(WIN32)
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include "windows_utils.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#define WIN_PATH_LIMIT 4096
#define WIN_MODE_LIMIT (3+1)

// MultiByteToWideChar wrapper:
//  CodePage: CP_UTF8
//  dwFlags: config
//  lpMultiByteStr: input char string
//  cbMultiByte: buf size of input, or -1 for null-terminated
//  lpWideCharStr: output string
//  cchWideChar: output size (0 to check for needed string)
// returns number of written chars including null, or 0 on error (not enough buffer, etc)
static int char_to_wchar(wchar_t* wdst, int wdst_size, const char* src) {
    // cchWideChar=0 means "get needed size", prone to subtle bugs
    if (!wdst || wdst_size <= 0 || !src) {
        //SetLastError(ERROR_INSUFFICIENT_BUFFER);
        return 0;
    }

    int src_size = -1; // input is null-terminated; will return 0 if not enough dst_size
    int done = MultiByteToWideChar(CP_UTF8, 0, src, src_size, wdst, wdst_size);
    if (done <= 0) {
        wdst[0] = 0;
    }
    return done;
}

// WideCharToMultiByte wrapper (assumes wstr is null-terminated):
//  CodePage: CP_UTF8
//  dwFlags: config
//  lpWideCharStr: input wchar_t string
//  cchWideChar: size of input, or -1 for null-terminated
//  lpMultiByteStr: output string
//  cbMultiByte: output size (0 to check for needed string)
//  lpDefaultChar: char to use for non-representable chars (NULL for default)
//  lpUsedDefaultChar: flag to check if default char was used
// returns number of written chars including null, or 0 on error (not enough buffer, etc)
static int wchar_to_char(char* dst, int dst_size, const wchar_t* wsrc) {
    // cbMultiByte=0 means "get needed size", prone to subtle bugs
    if (!dst || dst_size <= 0 || !wsrc) {
        //SetLastError(ERROR_INSUFFICIENT_BUFFER);
        return 0;
    }

    int wsrc_size = -1; // assumes input is null-terminated; will return 0 if not enough dst_size
    int done = WideCharToMultiByte(CP_UTF8, 0, wsrc, wsrc_size, dst, dst_size, NULL, NULL);
    if (done <= 0) {
        dst[0] = 0;
    }

    return done;
}


#if 0
// code below was left for testing purposes

#define WIN_LINE 2024 //big-ish for describe

/* Windows can fwprintf to console but only if mode is set to:
 *    _setmode(_fileno(stdout), _O_U16TEXT);
 * That breaks fprintf, but we can use Windows' WriteConsoleW to bypass it.
 * However that also doesn't work it stdout is redirected to a file.
 * So it needs to detect console and use WriteFile (seems the same as printf).
 * 
 * Alternatively just set console's codepage to UTF-8 + printf, seems to work well enough.
 */

static HANDLE get_windows_std_handle(FILE* stream) {
    if (stream == stdout) {
        static HANDLE hSdtout = NULL;
        if (!hSdtout)
            hSdtout = GetStdHandle(STD_OUTPUT_HANDLE);
        return hSdtout;
    }
    else if (stream == stderr) {
        static HANDLE hErrout = NULL;
        if (!hErrout)
            hErrout = GetStdHandle(STD_ERROR_HANDLE);
        return hErrout;
    }

    return NULL;
}

bool is_windows_console(HANDLE h) {
    if (!h)
        return false;

    DWORD type = GetFileType(h);
    if (type != FILE_TYPE_CHAR)
        return false;

    // TO-DO: mode flags?
    DWORD mode = 0;
    return GetConsoleMode(h, &mode);
}

// WriteConsoleW:
//   hConsoleOutput: 
//   lpBuffer: input wchar_t string
//   nNumberOfCharsToWrite: input len
//   lpNumberOfCharsWritten: output chars written (optional)
//   lpReserved: always NULL
// returns 0 on error

static bool fwprint_win(FILE* stream, const wchar_t* wtext, int wtext_len) {

    HANDLE hOut = get_windows_std_handle(stream);
    if (hOut) {
        if (wtext_len == 0)
            wtext_len = wcslen(wtext);
        int ret = WriteConsoleW(hOut, wtext, wtext_len, NULL, NULL);
        printf("wrote to console %i\n", ret);

        if (ret <= 0) return false;
    }
    else {
        printf("no handle\n");
        fwprintf(stream, L"%s", wtext);
    }

    return true;
}

static bool fprint_line(FILE* stream, const char* text, int text_len) {
    HANDLE hOut = get_windows_std_handle(stream);
    if (is_windows_console(hOut)) {
        wchar_t wtext[WIN_LINE];
        int wtext_len = char_to_wchar(wtext, WIN_LINE, text);
        if (wtext_len <= 0)
            return false;

        //if (wtext_len == 0)
        //    wtext_len = wcslen(wtext);
        int ret = WriteConsoleW(hOut, wtext, wtext_len, NULL, NULL);
        if (ret <= 0) return false;
    }
    else {
        //equivalent: fprintf(stream, "%s", text); 
        // also works for console but needs SetConsoleOutputCP(CP_UTF8)
        int ret = WriteFile(hOut, text, text_len, NULL, NULL);
        if (ret <= 0) return false;
    }

    return true;
}

static void fprintf_default(FILE* stream, const char* fmt, va_list args) {
    vfprintf(stream, fmt, args);
}

static void fprintf_args(FILE* stream, const char* fmt, va_list args) {
    char text[WIN_LINE];

    int done = vsnprintf(text, sizeof(text), fmt, args);
    if (done < 0 || done > sizeof(text)) {
        fprintf_default(stream, fmt, args);
        return;
    }

    bool ok = fprint_line(stream, text, done);
    if (!ok) {
        fprintf_default(stream, fmt, args);
    }
}

void printf_win(const char* fmt, ...) {
    va_list args;

    va_start(args, fmt);
    fprintf_args(stdout, fmt, args);
    va_end(args);
}

void fprintf_win(FILE* stream, const char* fmt, ...) {
    va_list args;

    va_start(args, fmt);
    fprintf_args(stream, fmt, args);
    va_end(args);
}
#endif

// Allows UTF-8 stdout output by programatically setting 'chcp 65001'
// win terminal needs a font that supports UTF-8; output redir (vgmstream-cli ... > blah.txt) works fine.
// Returns current codepage to be restored later.
static uint32_t windows_setup_codepage_utf8() {
    uint32_t prev_codepage = GetConsoleOutputCP();
    SetConsoleOutputCP(CP_UTF8);
    return prev_codepage;
}

// Restores original codepage since just in case.
static void windows_restore_codepage(uint32_t codepage) {
    SetConsoleOutputCP(codepage);
}

// copy to stack buf without allocs
static bool windows_wargs_to_args_stack(int argc, wchar_t** argv_w, char** argv, int argc_max, char* block, int block_size) {
    if (argc > argc_max)
        return false;

    for (int i = 0; i < argc; i++) {
        int done = wchar_to_char(block, block_size, argv_w[i]);
        if (done <= 0)
            return false;

        argv[i] = block;
        block += done;
        block_size -= done;
    }

    return true;
}

// copy to alloc'd buf with reallocs
static bool windows_wargs_to_args_alloc(int argc, wchar_t** argv_w, char*** p_argv, char** p_block) {
    int block_alloc_size = 0x2000;
    int block_pos = 0;
    int i;

    char** argv_alloc = NULL;
    char* block_alloc = NULL;

    argv_alloc = malloc(argc * sizeof(char*));
    if (!argv_alloc) goto fail;

    block_alloc = malloc(block_alloc_size);
    if (!block_alloc) goto fail;

    i = 0;
    while (i < argc) {
        char* block = block_alloc + block_pos;
        int block_size = block_alloc_size - block_pos;

        int done = wchar_to_char(block, block_size, argv_w[i]);
        if (done <= 0) {
            if (block_size > 0) {
                // <= 0 is not enough buf in this block
                DWORD err = GetLastError();
                if (err != ERROR_INSUFFICIENT_BUFFER)
                    goto fail;
            }

            if (block_alloc_size > 0x100000) //arbitrary max
                goto fail;

            // reserve more memory and retry (uncommon but needed if many files are passed)
            {
                int new_size = block_alloc_size * 2;
                char* new_block = realloc(block_alloc, new_size);
                if (!new_block) goto fail;

                block_alloc = new_block;
                block_alloc_size = new_size;
            }
        }
        else {
            argv_alloc[i] = block;
            block_pos += done;
            i++;
        }
    }

    *p_argv = argv_alloc;
    *p_block = block_alloc;
    return true;

fail:
    free(argv_alloc);
    free(block_alloc);
    return false;
}


static bool is_ascii(const char* str) {
    while (str[0] != 0x00) {
        uint8_t elem = (uint8_t)str[0];
        if (elem >= 0x80)
            return false;
        str++;
    }
    return true;
}

FILE* fopen_win(const char* path, const char* mode) {
    // Micro-optimization since converting small-ish ascii strings is the common case.
    // Possibly irrelevant since MultiByteToWideChar would do a full scan, but also extra steps.
    if (is_ascii(path)) {
        return fopen(path, mode);
    }

    int done;

    wchar_t wpath[WIN_PATH_LIMIT];
    done = char_to_wchar(wpath, WIN_PATH_LIMIT, path);
    if (done <= 0) return NULL;

    wchar_t wmode[WIN_MODE_LIMIT];
    done = char_to_wchar(wmode, WIN_MODE_LIMIT, mode);
    if (done <= 0) return NULL;

    return _wfopen(wpath, wmode);
}

#define WMAIN_STACK_ARGC 16
#define WMAIN_STACK_SIZE 0x800

extern int main(int argc, char** argv);

// TO-DO: alternatives for some Windows versions:
// - Windows 10 1803 (April 2018): setlocale(LC_ALL, ".utf8")
// - Windows 10 1903 (May 2019): activeCodePage=UTF8 in appxmanifest

// Handle Windows' uglycode stuff for non-ascii extended filenames, which needs 3 separate steps:
// - Make a 'wmain' for "unicode" (actually UCS-2) args. There are alt entry points but this was the cleanest.
// - Modify stdio, using _wfopen instead of fopen if needed
// - allow console/redirected output (printf), via codepages (or modified fprintf). Terminal needs a UTF font too.
// Converts back and forth to UTF-8 for portability, since vgmstream code expects that encoding.
int wmain_process(int argc, wchar_t** argv_w) {
    uint32_t codepage = windows_setup_codepage_utf8();

    int main_result = -1; // only 0/1 are returned

    // try to use small stack first as it's the most common case (single file with few params)
    {
        char* argv_stack[WMAIN_STACK_ARGC];
        char block_stack[WMAIN_STACK_SIZE];

        bool ok = windows_wargs_to_args_stack(argc, argv_w, argv_stack, WMAIN_STACK_ARGC, block_stack, WMAIN_STACK_SIZE);
        if (ok) {
            main_result = main(argc, argv_stack);
        }
    }

    // if stack wasn't big enough call again, alloc'ing as needed
    if (main_result < 0) {
        char** argv_alloc = NULL;
        char* block_alloc = NULL;

        bool ok = windows_wargs_to_args_alloc(argc, argv_w, &argv_alloc, &block_alloc);
        if (ok) {
            main_result = main(argc, argv_alloc);
        }

        if (argv_alloc || block_alloc) {
            free(argv_alloc);
            free(block_alloc);
        }
    }

    if (main_result < 0) {
        fprintf(stderr, "failed to convert args\n");
        return EXIT_FAILURE;
    }

    windows_restore_codepage(codepage);
    return main_result;
}


#endif
